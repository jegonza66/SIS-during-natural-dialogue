package objectsgames;

import java.io.*;
import java.net.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class GameClient {
    public static String dir;
    public static String iniFilename;
    public static String dirImages;

    int port;
    String hostname;

    /** This is used to control the speed of the graphical motions,
     *  such as sliding or blining images.
     *  speed > 0.0, where 1.0 means normal speed,
     *  >1.0 means faster motions, <1.0 means slower motions.
     *  It is initialized from the client.ini file. */
    public static double speed=1.0;

    public Log log;

    private JFrame frame;

    public HashMap clientConfigs;

    public static boolean DEVELOPING = false;

    Game game;

    Socket socket = null;
    ObjectInputStream in = null;
    ObjectOutputStream out = null;

    public final static Border buttonBorder = BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(Color.BLACK, 3),
                            BorderFactory.createEmptyBorder(10, 20, 10, 20));
    public final static Font buttonFont = new Font("Verdana", Font.BOLD, 20);
    public final static Color buttonColor = Color.WHITE;
    public final static Color tableColor = new Color(0, 145, 0);

    final static int width=1020, height=750;

    // ------------------------------------------------------------------------
    /** Constructor */
    public GameClient(JFrame frame) {
      this.frame = frame;
    }

    // ------------------------------------------------------------------------
    /** Reads a message from the server. */
    public Message readMessage() {
        Message m;
        try {
            m = (Message) in.readObject();
        }
        catch (IOException e) {
            m = null;
            System.err.println("IOException: " + e.toString());
        }
        catch (ClassNotFoundException e) {
            m = null;
            System.err.println("ClassNotFoundException: " + e.toString());
        }

        return m;
    }

    // ------------------------------------------------------------------------
    /** Sends a message to the server. */
    public void sendMessage(Message m) {
        try {
            out.writeObject(m);
        }
        catch (IOException e) {
            System.err.println("IOException" + e.toString());
        }
    }

    // ------------------------------------------------------------------------
    /** Opens a connection to the server. */
    private void openConnection() {
        try {
            socket = new Socket(hostname, port);
            in = new ObjectInputStream(socket.getInputStream());
            out = new ObjectOutputStream(socket.getOutputStream());
        } catch (UnknownHostException e) {
            System.err.println("UnknownHostException "+e.toString());
            System.exit(1);
        } catch (IOException e) {
            System.err.println("IOException: "+e.toString());
            System.exit(1);
        }
    }

    // ------------------------------------------------------------------------
    /** Opens the connection to the server. */
    private void closeConnection() {
        try {
            in.close();
            socket.close();
        }
        catch (IOException e) {
            System.err.println("IOException: " + e.toString());
        }
    }

    // ------------------------------------------------------------------------
    /** Checks if the message m has the given messageNumber. */
    public void checkMessage(Message m, int messageNumber) {
        if (m.getMessageNumber() != messageNumber) {
            System.err.println("Protocol Error. Message number expected: "
                + Integer.toString(messageNumber)
                + ". Message number received: "
                + Integer.toString(m.getMessageNumber())
            );
            closeConnection();
            System.exit(1);
        }
    }

    // ------------------------------------------------------------------------
    /** Initialization */
    private void init() {
        Message m;

        m = readMessage();
        checkMessage(m, Message.SERVER_INIT);

        clientConfigs = m.getHashMap();

        // if we are still working on this, set the DEVELOPING variable.
        // this affects (e.g.) the Log, the delays in the TopMessageDisplay,
		// the possibility to close or not the client's window, etc.
        if (clientConfigs.containsKey("developing")) {
            DEVELOPING = clientConfigs.get("developing").equals("true");
        }

        // Creates the log
        log = new Log();
    }

    // ------------------------------------------------------------------------
    /** Closing up... */
    private void end() {
        Message m = readMessage();
        checkMessage(m, Message.SERVER_END);
    }

    // ------------------------------------------------------------------------
    /** Synchronization with the server and the other client. */
    public void synchronize() {
        sendMessage(new Message(Message.CLIENT_ACK));
        Message m = readMessage();
        checkMessage(m, Message.SERVER_ACK);
    }

    // ------------------------------------------------------------------------
    /** Make a BEEP and log it. */
    public void beep() {
        Toolkit.getDefaultToolkit().beep();
        log.write(Log.ACTION_BEEP, "");
    }

    // ------------------------------------------------------------------------
    /** Reads the info from the ini file. */
    public void readIniFile() {
        try {
            File f = new File(dir + iniFilename);

            BufferedReader br = new BufferedReader(new FileReader(f));
            while (br.ready()) {
                String line = br.readLine();
                if (line.startsWith("#")) {
                    // this is a comment. do nothing.
                }
                else if (line.startsWith("port=")) {
                    port = Integer.parseInt(line.substring(5));
                }
                else if (line.startsWith("hostname=")) {
                    hostname = line.substring(9);
                }
                else if (line.startsWith("speed=")) {
                    speed = Double.parseDouble(line.substring(6));
                }
            }
        }
        catch (FileNotFoundException e) {
            System.err.println("FileNotFoundException: " + e.toString());
            System.exit(1);
        }
        catch (IOException e) {
            System.err.println("IOException: " + e.toString());
            System.exit(1);
        }
    }

    // ------------------------------------------------------------------------
    /** This method is called by Main.java to start a client. */
    public static void start(String dir, String iniFilename) {
        //Create and set up the window.
        JFrame frame = new JFrame("Game");
        frame.setUndecorated( true );
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        //Display the window and maximize it.
        frame.pack();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);

        GameClient.dir = dir + File.separator;
        GameClient.iniFilename = iniFilename;
        GameClient.dirImages = GameClient.dir + "images" + File.separator;

        GameClient gameClient = new GameClient(frame);
        gameClient.readIniFile();
        gameClient.openConnection();
        gameClient.init();

        // Only allow to close the client if we're developing.
        if (GameClient.DEVELOPING) {
            frame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    System.exit(0);
                }
            });
        }

        gameClient.game = new Game(gameClient);
        frame.setContentPane(gameClient.game);
        frame.pack();

        gameClient.game.go();

        gameClient.end();
        gameClient.closeConnection();

        System.exit(0);
    }
}
