package objectsgames;

import java.net.*;
import java.io.*;
import java.util.*;
import java.text.*;
import java.awt.*;

public class GameServer {
    String dir;
    String iniFilename;
    String hiScoreFilename;

    int port;

    ServerSocket serverSocket = null;
    Socket client1Socket = null;
    Socket client2Socket = null;

    ObjectInputStream in1 = null;
    ObjectInputStream in2 = null;
    ObjectOutputStream out1 = null;
    ObjectOutputStream out2 = null;

    HashMap clientConfigs;
    
    Vector images;          // Vector of Vectors of Strings, with the image names for each turn
                            // (ej: 'circle' --> 'images/circle.gif')
                            // If images[T]==null then the images for turn T are the same as for
                            // for turn T-1. Thus, images[0] should never be null.
                            // All vectors of images MUST BE THE SAME SIZE.
    
    int numberOfTurns;      // in each turn: one player describes and the other plays, alternating
    Vector positions;       // Vector of Vectors of Points. Each Point has x, y coordinates
    Vector targetImages;    // Vector of Vector of Integer, with the indices of the target images
    Vector whoDescribes;    // Vector of Integer. Says which player (1 or 2) describes each turn.
    
    int hiScore;
    
    final int MAXPOINTS = 100;

  public GameServer(String dir, String iniFilename) {
    this.dir = dir + File.separator;
    this.iniFilename = iniFilename;
    this.hiScoreFilename = "hiscore.ini";
  }

    

    // ************************************************************************
    /** Reads a message from a client. */
    private Message readMessage(int clientNumber) {
        Message m;

        try {
            if (clientNumber==1)
                m = (Message)in1.readObject();
            else
                m = (Message)in2.readObject();
        }
        catch (IOException e) {
            m = null;
            System.err.println("IOException: " + e.toString());
        }
        catch (ClassNotFoundException e) {
            m = null;
            System.err.println("ClassNotFoundException: " + e.toString());
        }

        return m;
    }

    // ************************************************************************
    /** Sends a message to a client. */
    private void sendMessage(int clientNumber, Message m) {
        try {
            if (clientNumber==1)
                out1.writeObject(m);
            else
                out2.writeObject(m);
        }
        catch (IOException e) {
            System.err.println("IOException" + e.toString());
        }
    }

    // ************************************************************************
    /** Opens the connection between the server and the clients. */
    private void openConnection() {
        try {
            serverSocket = new ServerSocket(port);
            
            client1Socket = serverSocket.accept();
            client1Socket.setKeepAlive(true);
            client2Socket = serverSocket.accept();
            client2Socket.setKeepAlive(true);
            
            out1 = new ObjectOutputStream(client1Socket.getOutputStream());
            out2 = new ObjectOutputStream(client2Socket.getOutputStream());
            in1 = new ObjectInputStream(client1Socket.getInputStream());
            in2 = new ObjectInputStream(client2Socket.getInputStream());
        }
        catch (IOException e) {
            System.err.println("IOException: "+e.toString());
            System.exit(1);
        }
    }

    // ************************************************************************
    /** Closes the connection between the server and the clients. */
    private void closeConnection() {
        try {
            out1.close();
            out2.close();
            client1Socket.close();
            client2Socket.close();
            serverSocket.close();
        }
        catch (IOException e) {
            System.err.println("IOException: "+e.toString());
            System.exit(1);
        }
    }

    // ************************************************************************
    /** Checks if the message m has the given messageNumber. */
    private void checkMessage(Message m, int messageNumber) {
        if (m.getMessageNumber() != messageNumber) {
            System.err.println("Protocol Error. Message number expected: "
                + Integer.toString(messageNumber)
                + ". Message number received: "
                + Integer.toString(m.getMessageNumber())
            );
            closeConnection();
            System.exit(1);
        }
    }

    // ************************************************************************
    /** Initialization */
    private void init() {
        Message m = new Message(Message.SERVER_INIT, clientConfigs);
        sendMessage(1, m);
        sendMessage(2, m);
    }

    // ************************************************************************
    /** Closing up... */
    private void end() {
        Message m = new Message(Message.SERVER_END);
        sendMessage(1, m);
        sendMessage(2, m);
    }


    // ************************************************************************
    private void playTheGame() {
        Message m;
        HashMap hm;
        
        int currentTurn = 0;

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
        
        hm = new HashMap();
        hm.put(Message.LABEL_NUMBER_OF_IMAGES, new Integer(((Vector) images.firstElement()).size()));
        
        sendMessage(1, new Message(Message.SERVER_START, hm));
        sendMessage(2, new Message(Message.SERVER_START, hm));

        synchronize();
        
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
        
        while (currentTurn < numberOfTurns) {
            // A places the image, B describes.
            int playerA, playerB;

            if (((Integer) whoDescribes.elementAt(currentTurn)).intValue() == 1) {
                playerA = 2; playerB = 1;
            } else {
                playerA = 1; playerB = 2;
            }

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

            // if there is a new set of images for this turn, send it to the clients
            if (images.elementAt(currentTurn) != null) {
                hm = new HashMap();
                Vector turnImages = (Vector) images.elementAt(currentTurn);
                hm.put(Message.LABEL_IMAGES, turnImages);
                sendMessage(playerA, new Message(Message.SERVER_NEW_IMAGES, hm));
                sendMessage(playerB, new Message(Message.SERVER_NEW_IMAGES, hm));

                m = readMessage(1); checkMessage(m, Message.CLIENT_ACK);
                m = readMessage(2); checkMessage(m, Message.CLIENT_ACK);
            }

            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

            // send the NEW TURN message to the clients.
            
            hm = new HashMap();

            // positions and target images for the current turn
            Vector turnPositions    = (Vector) positions.elementAt(currentTurn);
            Vector turnTargetImages = (Vector) targetImages.elementAt(currentTurn);
            hm.put(Message.LABEL_POSITIONS,     turnPositions);
            hm.put(Message.LABEL_TARGET_IMAGES, turnTargetImages);

            hm.put(Message.LABEL_YOU_DESCRIBE, Boolean.FALSE);
            sendMessage(playerA, new Message(Message.SERVER_NEW_TURN, hm));

            hm.put(Message.LABEL_YOU_DESCRIBE, Boolean.TRUE);
            sendMessage(playerB, new Message(Message.SERVER_NEW_TURN, hm));
            
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
            
            m = readMessage(playerA); checkMessage(m, Message.CLIENT_POSITIONS);
            Vector playersPositions = (Vector) m.getHashMap().get(Message.LABEL_POSITIONS);
            
            int points = 0;
            for (int i=0; i<turnTargetImages.size(); i++) {
                int imgIndex = ((Integer) turnTargetImages.elementAt(i)).intValue();
                
                Point playersGuess   = (Point) playersPositions.elementAt(imgIndex);
                Point actualPosition = (Point) turnPositions.elementAt(imgIndex);
                
                points += calculatePoints(actualPosition, playersGuess);
            }
            
            hm = new HashMap();
            hm.put(Message.LABEL_POINTS, new Integer(points));
            hm.put(Message.LABEL_POSSIBLE_POINTS, new Integer(MAXPOINTS * turnTargetImages.size()));
            hm.put(Message.LABEL_POSITIONS, playersPositions);
            sendMessage(playerA, new Message(Message.SERVER_LAST_TURN_RESULTS, hm));
            sendMessage(playerB, new Message(Message.SERVER_LAST_TURN_RESULTS, hm));
        
            m = readMessage(1); checkMessage(m, Message.CLIENT_ACK);
            m = readMessage(2); checkMessage(m, Message.CLIENT_ACK);
            
            currentTurn++;
        }
        
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

        sendMessage(1, new Message(Message.SERVER_END));
        sendMessage(2, new Message(Message.SERVER_END));

        m = readMessage(1); checkMessage(m, Message.CLIENT_MY_SCORE);
        m = readMessage(2); checkMessage(m, Message.CLIENT_MY_SCORE);
        
        int score = ((Integer) m.getHashMap().get(Message.LABEL_POINTS)).intValue();
        
        // Updates the high score, if necessary.
        if (score > hiScore) saveHiScore(score); 
        
    }

    // ************************************************************************
    /** Reads the info in the server.ini file. */
    public void readIniFile() {

        numberOfTurns = 0;
        
        images       = new Vector();
        positions    = new Vector();
        targetImages = new Vector();
        whoDescribes = new Vector();

        String openTag = null;

        clientConfigs = new HashMap();

        hiScore = loadHiScore();
        clientConfigs.put("hiscore", Integer.toString(hiScore));
        
        try {
            File f = new File(dir + iniFilename);

            BufferedReader br = new BufferedReader(new FileReader(f));
            while (br.ready()) {
                String line = br.readLine();

                if (line.startsWith("#")) {
                    // this is a comment. do nothing.
                }

                else if  (line.equals("</IMAGES>") || line.equals("</TURN>"))
                    openTag = null;

                else if (openTag != null) {
                    if (openTag.equals("IMAGES")) {
                        // add this image to this turn's vector of images
                        ((Vector) images.lastElement()).add(line);
                    }
                    else if (openTag.equals("TURN")) {
                        String[] coord = line.trim().split(" ");
                        if (coord.length==2  ||  coord.length==3) {
                            Point p = new Point(Integer.parseInt(coord[0]), Integer.parseInt(coord[1]));
                            ((Vector) positions.lastElement()).add(p);
                            
                            // this image is marked as 'target' in this turn
                            if (coord.length==3  &&  coord[2].equals("target")) {
                                // get the index of this image
                                int imageIndex = ((Vector) positions.lastElement()).size() - 1;
                                ((Vector) targetImages.lastElement()).add(new Integer(imageIndex));
                            }
                        }
                    }
                }

                else if (line.startsWith("port=")) {
                    port = Integer.parseInt(line.substring(5));
                }

                else if (line.equals("<IMAGES>")) {
                    openTag = "IMAGES";
                    
                    // add a new vector in the images vector, for the images in this turn.
                    images.add(new Vector());
                }

                else if (line.equals("<TURN DESCRIBER=1>") ||
                         line.equals("<TURN DESCRIBER=2>")) {
                    openTag = "TURN";
                    numberOfTurns++;
                    
                    // if there is no set of images (<IMAGES>) for this turn, 
                    // add a null element in the images vector.
                    if (images.size() < numberOfTurns) images.add(null);
                    
                    positions.add(new Vector());
                    targetImages.add(new Vector());
                    
                    if (line.equals("<TURN DESCRIBER=1>"))
                        whoDescribes.add(new Integer(1));
                    else
                        whoDescribes.add(new Integer(2));
                }

                else {
                    // client configurations
                    // these are passed in the clientConfigs hashmap to the clients

                    String[] fs = { // fields
                        "developing",
                    };

                    for (int i=0; i<fs.length; i++) {
                        if (line.startsWith(fs[i]+"=")) {
                            // store name and value of this field in the clientConfigs hashmap
                            clientConfigs.put(fs[i], line.substring(fs[i].length()+1));
                        }
                    }
                }
            }
        }
        catch (FileNotFoundException e) {
            System.err.println("FileNotFoundException: " + e.toString());
            System.exit(1);
        }
        catch (IOException e) {
            System.err.println("IOException: " + e.toString());
            System.exit(1);
        }
    }

    // ************************************************************************
    /** Loads the high score from the corresponding file. */
    private int loadHiScore() {
        int hs=0;
        try {
            File f = new File(dir + hiScoreFilename);
            BufferedReader br = new BufferedReader(new FileReader(f));
            if (br.ready()) {
                String line = br.readLine();
                hs = Integer.parseInt(line);
            }
        }
        catch (FileNotFoundException e) {
            System.err.println("FileNotFoundException: " + e.toString());
        }
        catch (IOException e) {
            System.err.println("IOException: " + e.toString());
        }
        return hs;
    }

    // ************************************************************************
    /** Saves the high score in the corresponding file. */
    private void saveHiScore(int hs) {
        try {
            FileWriter fw = new FileWriter(dir + hiScoreFilename);
            fw.write(Integer.toString(hs));
            fw.close();
        }
        catch (IOException e) {
            System.err.println(e.toString());
        }
    }

    // ************************************************************************
    /** Synchronization with the two clients, used for example
     *  while each of them shows a dialog. */
    private void synchronize() {
        Message m;
        m = readMessage(1);
        m = readMessage(2);
        sendMessage(1, new Message(Message.SERVER_ACK));
        sendMessage(2, new Message(Message.SERVER_ACK));
    }
    
    // ************************************************************************
    
    /** Calculate the points given to the player, in function of how far
     *  they placed the image from the actual position. */
    private int calculatePoints(Point actualPosition, Point playersGuess) {
        double distance = actualPosition.distance(playersGuess);
        
        int res =  MAXPOINTS - (int)Math.round(distance / 1);
       
        if (res < 0) res = 0;
        
        return res;        
    }

    // ************************************************************************

    /** This method is called by Main.java to start a Server. */
    public static void start(String dir, String iniFilename) {

      GameServer gameServer = new GameServer(dir, iniFilename);

      gameServer.readIniFile();
      gameServer.openConnection();
      gameServer.init();
      gameServer.playTheGame();
      gameServer.end();
      gameServer.closeConnection();
    }
}
