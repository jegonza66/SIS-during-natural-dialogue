package objectsgames;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class ToggleVisible extends TimerTask {
    private Component component;
    private int iterations, proportionOnOff, counter;
    private boolean forEver;

    /** Prepares component c to blink for ever. */
    public ToggleVisible (Component comp, int proportionOnOff) {
        this.component       = comp;
        this.proportionOnOff = proportionOnOff;
        this.forEver         = true;
    }
        
    /** Prepares component c to blink upto 'iterations' times (not for ever). 
     *  proportionOnOff sets the number of times that the component is ON
     *  for each time it's OFF. 
     *  examples: if it's 1: ON OFF ON OFF ON OFF ON OFF...
     *            if it's 2: ON ON OFF ON ON OFF ON ON OFF...
     */
    public ToggleVisible (Component comp, int proportionOnOff, int iterations) {
        this.component       = comp;
        this.iterations      = iterations;
        this.proportionOnOff = proportionOnOff;
        this.forEver         = false;
        this.counter         = 0;
    }

    /** Starts blinking / toggles the component's visibility.
     *  Either continues for ever or stops after a number of iterations. */
    public void run() {
        if (component.isVisible()) {
            counter++;
            if (counter >= proportionOnOff)
                component.setVisible(false);
        } else {
            component.setVisible(true);
            counter = 0;
            iterations--;
        }
        if (!forEver && iterations<=0) this.cancel();
    }
}
