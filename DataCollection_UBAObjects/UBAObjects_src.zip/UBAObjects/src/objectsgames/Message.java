package objectsgames;

import java.io.*;
import java.util.*;

public class Message implements Serializable {
    int messageNumber = 0;

    HashMap hm = null;
    
    /********** server-to-client messages. **************/
    /** Initialization -- Requires a HashMap. */
    public static final int SERVER_INIT                        = 1000;

    /** Closing up... */
    public static final int SERVER_END                         = 1001;

    /** "Ack" (Sent after both clients have ack'ed the results of a move. */
    public static final int SERVER_ACK                         = 1002;
    
    /** "The game has finished." */
    public static final int SERVER_GAME_END                    = 1003;
    
    
    /** "The game has started." 
     *  hm('numberOfImages') --> Integer           (number of images, the same for all the game)
     */
    public static final int SERVER_START                       = 1;
    
    
    /** "Change the set of images."
     *  hm('images') --> Vector of Strings         (names of the images)
     */
    public static final int SERVER_NEW_IMAGES                  = 2;
    
    /** "Start a new turn."
     *  hm('positions') --> Vector of Points       (positions of the images)
     *  hm('target images') --> Vector of Integer  (indices of the target images)
     *  hm('you describe') --> Boolean             (true: you describe, false: you place the image) 
     */
    public static final int SERVER_NEW_TURN                    = 3;
    
    /** "These were last turn's results."
     *  hm('points') --> Integer                   (points awarded)
     *  hm('possible points') --> Integer          (possible number of points)
     *  hm('positions') --> Vector of Points       (positions where the player placed the images)
     */
    public static final int SERVER_LAST_TURN_RESULTS           = 4;

    
    /********** client-to-server messages. **************/
    /** "The player has placed the images here."
     *  hm('positions') --> Vector of Points      (position of the images)
     */     
    public static final int CLIENT_POSITIONS                   = 50;

    /** "This was this player's final score." 
     *  hm('points') --> Integer
     */     
    public static final int CLIENT_MY_SCORE                    = 51;
    
    /** "Ack" */
    public static final int CLIENT_ACK                         = 2002;
    
    /** "End the game now." */
    public static final int CLIENT_GAME_END                    = 2003;

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    /** Label for the Message's HashMap: 
     *  Integer with the number of images, the same for all the game. */
    public static final String LABEL_NUMBER_OF_IMAGES = "number of images";

    /** Label for the Message's HashMap: 
     *  Vector with the GameImages for this game. */
    public static final String LABEL_IMAGES        = "images";

    /** Label for the Message's HashMap:
     *  Vector with the positions (Points) of images. */
    public static final String LABEL_POSITIONS     = "positions";
    
    /** Label for the Message's HashMap: 
     *  Integer with the indices of the target images for this turn. */
    public static final String LABEL_TARGET_IMAGES = "target images";

    /** Label for the Message's HashMap: 
     *  Boolean that says if the destination player describes (true) or plays (false). */
    public static final String LABEL_YOU_DESCRIBE  = "you describe";
    
    /** Label for the Message's HashMap: 
     *  Integer with the points achieved last turn. */
    public static final String LABEL_POINTS        = "points";

    /** Label for the Message's HashMap: 
     *  Integer with the possible amount points that could have been achieved last turn. */
    public static final String LABEL_POSSIBLE_POINTS = "possible points";
    
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    
    /** Constructor */
    public Message(int messageNumber) {
        this.messageNumber = messageNumber;
        this.hm = null;
    }

    /** Constructor */
    public Message(int messageNumber, HashMap hm) {
        this.messageNumber = messageNumber;
        this.hm = hm;
    }

    public int getMessageNumber()  { return messageNumber; }    
    public HashMap getHashMap()  { return hm; }
    
}
