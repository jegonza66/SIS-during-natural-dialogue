package objectsgames;

import java.io.*;
import java.util.*;
import java.text.*;

public class Log {
    public static final String ACTION_VOID                  = "VOID";
    public static final String ACTION_BEGIN_EXECUTION       = "BEGIN_EXECUTION";
    public static final String ACTION_BEEP                  = "BEEP";
    
    public static final String ACTION_NEXT_TURN             = "NEXT_TURN";
    public static final String ACTION_RESULTS               = "RESULTS";
    public static final String ACTION_END                   = "END";
    
    File file;
    String filename;
    SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss:SSS");
    
    final String TAB="\t", NEWLINE="\n";
        
    public Log() {
        if (GameClient.DEVELOPING) return;
        
        Calendar cal = Calendar.getInstance(TimeZone.getDefault());
        SimpleDateFormat df1 = new SimpleDateFormat("yyyyMMdd_HHmmss");
        Date now = cal.getTime();
        filename = GameClient.dir + "logs/" + df1.format(now) + ".log";
        file = new File(filename);
        
        int aux = 0;
        while (file.exists()) {
            filename = GameClient.dir + "logs/" + df1.format(now) + "~" + Integer.toString(aux) + ".log";
            file = new File(filename);
            aux++;
        }
  
        write(ACTION_BEGIN_EXECUTION, "");
    }

    public void write(String action, String description) {
        if (GameClient.DEVELOPING) return;
        
        Calendar cal = Calendar.getInstance(TimeZone.getDefault());
        String now = timeFormat.format(cal.getTime());

        try {
            FileWriter fw = new FileWriter(filename, true);
            fw.write(now + TAB + action + TAB + description + NEWLINE);
            fw.close();
        }
        catch (IOException e) {
            System.err.println(e.toString());
            System.exit(1);
        }
    }
}
