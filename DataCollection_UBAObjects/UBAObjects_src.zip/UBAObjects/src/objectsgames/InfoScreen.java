package objectsgames;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class InfoScreen extends JPanel {
    // constants used to call show(int):

    // the following five are not currently used
    public static final int INTRO_GAME             = 1;
    public static final int INTRO_GAME_2           = 2;
    public static final int END_GAME               = 100;
    public static final int WAITING_FOR_USER       = 200;

    static final String FONT_STYLE = "font-family: arial; font-size:18px; color:#000000; font-weight:normal";
//DEL    static final String FONT_STYLE_OPEN = "<font face=arial size=\"20px\" color=black>";
//DEL    static final String FONT_STYLE_CLOSE = "</font>";

//AG2012    private GameClient gameClient;

    JButton continueButton;
    JEditorPane contents;
    JPanel buttonPane;
    JLabel pageLabel;

    static String dir;
    int titlePhaseNumber = 0;
    int auxForSavingHtmlFile = 0;

    boolean waitingForUser=false;

    /** Constructor */
    public InfoScreen(GameClient gameClient) {
        super(new BorderLayout());
//AG2012        this.gameClient = gameClient;
        setPreferredSize(new Dimension(GameClient.width, GameClient.height));

        // ------- BUTTON --------
        continueButton = new JButton("CONTINUAR");
        continueButton.setActionCommand("continue");
        continueButton.addActionListener(new ButtonListener());
        continueButton.setFont(GameClient.buttonFont);
        continueButton.setToolTipText("Click here to continue.");
        continueButton.setBorder(GameClient.buttonBorder);
        continueButton.setBackground(GameClient.buttonColor);
        continueButton.setEnabled(true);

        // ------- PAGE LABEL --------
        pageLabel = new JLabel("");
        pageLabel.setFont(new Font("Verdana", Font.BOLD, 20));
        pageLabel.setVisible(false);

        buttonPane = new JPanel();
        buttonPane.add(pageLabel);
        buttonPane.add(continueButton);

        setLayout(new BorderLayout());

        // ------ CONTENTS ------
        contents = new JEditorPane("text/html", "");
        contents.setPreferredSize(new Dimension(GameClient.width-10, GameClient.height-100));
        contents.setEditable(false);

        add(contents, BorderLayout.CENTER);

//        EL CODIGO DEL DEMONIO.... SCROLL-PAIN!!!!!!!!!
//        JScrollPane scrollPane = new JScrollPane(contents);
//        scrollPane.setPreferredSize(new Dimension(GameClient.width-10, GameClient.height-100));
//        add(scrollPane, BorderLayout.CENTER);

        add(buttonPane, BorderLayout.SOUTH);
    }

    // ************************************************************************
    //  This code is for changing the contents of the info-screen and looping
    //  until the user clicks the CONTINUE button.

    /** Changes the content and loops until the user hits CONTINUE. */
    private synchronized void show(String htmlText, boolean showContinueButton) {

        // show the new html contents
        String w = Integer.toString(GameClient.width-15);
        String html="";
        html += "<table width='"+ w +"' align='center' cellpadding='0' cellspacing='0' bgcolor='#FFFFFF' border='0'>";
        html += "<tr><td align='center' style='"+ FONT_STYLE +"'>";
//DEL        html += "<tr><td align='center'>"+ FONT_STYLE_OPEN;
        html += htmlText;
//DEL        html += FONT_STYLE_CLOSE + "</td></tr>";
        html += "</td></tr>";
        html += "</table>";
        contents.setText(html);

        // show the continue button, if necessary
        buttonPane.setVisible(showContinueButton);

        repaint();

        // if showing the continue button, wait for the user to click it.
        if (showContinueButton) {
            continueButton.grabFocus();
            waitingForUser = true;
            while (waitingForUser) {
                try {
                    Thread.currentThread().sleep(100);
                }
                catch (InterruptedException e) {}
            }
        }

        // This is for printing the html to files.
        if (false) {
            try {
                String fn = dir + Integer.toString(auxForSavingHtmlFile)+".html";
                auxForSavingHtmlFile++;
                FileWriter fw = new FileWriter(fn, true);
                fw.write(html);
                fw.close();
            }
            catch (IOException e) {
                System.err.println(e.toString());
                System.exit(1);
            }
        }
    }

    /** Changes the contents and loops until the user clicks the CONTINUE button.
     *  The screen argument can be one of the static constants of this class
     *  (INTRO_GAME, PHASE_ONE_DESCRIBE, etc.) */
    public void show(int screen) {
        show(screen, "");
    }

    /** Changes the contents and loops until the user clicks the CONTINUE button.
     *  The screen argument can be one of the static constants of this class
     *  (INTRO_GAME, PHASE_ONE_DESCRIBE, etc.).
     *  aux is an optional Object, representing:
     *  - if screen is END_GAME: a String with the player's final score
     *  - if screen is INTRO_GAME: a Hashmap of character_name --> character
     *    (eg: romeo --> blue_lion)
     */
    public void show(int screen, Object aux) {
        boolean showContinueButton = true;

        String htmlText="";
        setPageLabel("");

        switch (screen) {
            case INTRO_GAME:
                setPageLabel("PAGE 1 OF 2");

                htmlText += "<b>¡BIENVENIDO/A!</b><br>";
                htmlText += "<table align=\"center\" width=\"75%\" border=\"0\"><tr><td align=left>";
                htmlText += "<p>En este juego, tenés que trabajar en conjunto "
                            + "con tu compañero/a para colocar algunos objetos "
                            + "en la posición correcta en tu pantalla.</p>";
                
                File file = new File(GameClient.dirImages + "intro1.gif");
                htmlText += "<p>Durante el juego, tu pantalla estará dividida en dos partes:" +
                            " el <b>tablero de juego</b> y el <b>inventario</b>.</p>" +
                            "<p>Este es un ejemplo de tablero e inventario:</p>" +
                            "<p align=center><img src=\"file://" + file.getAbsolutePath() + "\"></p>";
                htmlText += "<p align=\"center\"><i>Cuando hayas terminado de leer, presioná 'CONTINUAR'.</i></p>";
                htmlText += "</td></tr></table>";

                break;

            case INTRO_GAME_2:
                setPageLabel("PAGE 2 OF 2");

                htmlText += "<b>REGLAS DEL JUEGO</b>";
                htmlText += "<table align=center width=\"75%\" border=0><tr><td align=left>";
                htmlText += "<p>Vos y tu compañero/a tendrán el mismo conjunto de objetos " +
                            "ubicados en posiciones idénticas en los dos tableros. " +
                            "En cada turno, un jugador <b>describe</b>, " +
                            "y el otro <b>escucha</b>.";
                htmlText += "<p>En el tablero del <b>jugador que describe</b>, un objeto " +
                            "estará titilando. Ese objeto no aparecerá en el tablero del otro jugador, " +
                            "pero sí en su inventario. El jugador que describe " +
                            "deberá describir la ubicación exacta del objeto que titila, relativa a los otros objetos " +
                            "en el tablero.</p>" +
                            "<p>Mientras tanto, el <b>jugador que escucha</b> usará esas descripciones para " +
                            "mover su objeto desde el inventario hasta su ubicación correcta en el tablero.</p>";
                
                htmlText += "<font style=\"font-size: 1px\"><BR></font>";
                htmlText += "<table align=center border=0><tr>";

                file = new File(GameClient.dirImages + "intro2.gif");
                htmlText += "<td><img src=\"file://" + file.getAbsolutePath() + "\"></td>";
                htmlText += "<td>&nbsp;&nbsp;&nbsp;</td>";

                file = new File(GameClient.dirImages + "intro3.gif");
                htmlText += "<td><img src=\"file://" + file.getAbsolutePath() + "\"></td>";
                htmlText += "</tr><tr>";
                htmlText += "<td style=\"font-size: 16px\" align=center>Tablero del jugador que describe</td>";
                htmlText += "<td></td>";
                htmlText += "<td style=\"font-size: 16px\" align=center>Tablero del jugador que escucha</td>";
                htmlText += "</tr></table>";
                
                htmlText += "<p>El puntaje se calcula en una escala de 0 a 100. Cuanto más cerca de su ubicación exacta se coloque al objeto, " +
                            "mayor será el puntaje obtenido.</p>";
                htmlText += "</td></tr></table>";

                break;

            case END_GAME:
                htmlText = "<b>FIN DEL JUEGO</b><br><br>";
                htmlText += "<table align=\"center\" width=\"75%\" border=\"0\"><tr><td>";
                htmlText += "<p align=\"left\">¡Muchas gracias por tu participación!</p>";
                htmlText += "<p align=\"left\">" + (String) aux + "</p></td></tr></table>";
                continueButton.setText("TERMINAR");
                break;

            case WAITING_FOR_USER:
                htmlText = "Esperando al otro jugador...";
                showContinueButton = false;
                break;

            default:
                htmlText = "";
        }
        show(htmlText, showContinueButton);
    }

    // ************************************************************************

    /** Button listener. */
    private class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("continue")) {
                //endWaitForUser();
                waitingForUser = false;
            }
        }
    }

    // ************************************************************************

    private void setPageLabel(String txt) {
        if (txt.equals("")) {
            pageLabel.setVisible(false);
        } else {
            pageLabel.setText(txt + "       ");
            pageLabel.setVisible(true);
        }
    }

    // ------------------------------------------------------------------------
    /** FOR TESTING */
    public static void main(String[] args) {

        // read the dir from the arguments..
        dir="";
        for (int i=0; i<args.length; i++) {
            if (args[i].startsWith("-dir=")) {
                dir = args[i].substring(5);
            }
        }
        if (dir.equals(""))  dir=System.getProperty("user.dir") + File.separator;
        GameClient.dirImages = dir + "images" + File.separator;

        JFrame frame = new JFrame("Game");
        frame.setUndecorated( true );
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        //Display the window and maximize it.
        frame.pack();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);

        GameClient gc = new GameClient(frame);
        gc.clientConfigs = new HashMap();
        gc.clientConfigs.put("hiscore", "99");
        gc.game = new Game(gc);

        frame.setContentPane(gc.game);

        gc.game.infoScreen = new InfoScreen(gc);
        gc.game.add(gc.game.infoScreen);

        gc.game.infoScreen.show(InfoScreen.INTRO_GAME);
        gc.game.infoScreen.show(InfoScreen.INTRO_GAME_2);

        System.exit(0);
    }
}