package objectsgames;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.io.*;
import java.util.*;
import java.net.URL;
import java.text.DecimalFormat;

public class Game extends JPanel {

    // components
    GameClient gameClient;
    GameWorkspace workspace;
    JPanel mainPane, topPane, buttonPane, scorePane;
    JButton doneButton, continueButton;
    InfoScreen infoScreen;
    JLabel scoreLabel, scoreTitleLabel, hiScoreLabel, hiScoreTitleLabel;
    TopMessageDisplay topMessageDisplay;


    // variables and constants
    int score, hiScore ;
    final String SCORE_PATTERN = "000";  // format of the scores, used with DecimalFormat.
    int currentTurn = 0;
    int numberOfTurns;
    int numberOfImages;
    GameImage[] images;    // array with the images
    int[] targetImages;    // indices of the current target image
    Point[] positions;     // array with the positions of the images

    int playerState;  // player state, can be one of the following:
    static final int PLAYER_STATE_IDLE       = 0;
    static final int PLAYER_STATE_DESCRIBING = 1;
    static final int PLAYER_STATE_PLAYING    = 2;

    int FIELD_OFFSET_X = 10;
    int FIELD_OFFSET_Y = 10;

    
    /** Constructor */
    public Game(GameClient gameClient) {
        super(new BorderLayout());
        this.gameClient = gameClient;
        setPreferredSize(new Dimension(GameClient.width, GameClient.height));
        setOpaque(true);
        
        playerState = PLAYER_STATE_IDLE;

        infoScreen = new InfoScreen(gameClient);

        // ------------ DONE & CONTINUE BUTTONS --------------
        doneButton = new JButton("LISTO");
        doneButton.setActionCommand("done");
        doneButton.addActionListener(new ButtonListener());
        doneButton.setEnabled(false);
        doneButton.setFont(GameClient.buttonFont);
        doneButton.setBorder(GameClient.buttonBorder);
        doneButton.setBackground(GameClient.buttonColor);     //new Color(160, 255, 160)
        doneButton.setPreferredSize(new Dimension(210, 50));

        continueButton = new JButton("CONTINUAR");
        continueButton.setActionCommand("continue");
        continueButton.addActionListener(new ButtonListener());
        continueButton.setEnabled(false);
        continueButton.setFont(GameClient.buttonFont);
        continueButton.setBorder(GameClient.buttonBorder);
        continueButton.setBackground(GameClient.buttonColor);   //new Color(160, 160, 255)
        continueButton.setPreferredSize(new Dimension(210, 50));

        // ------------ SCORE & HI-SCORE --------------
        scoreTitleLabel = new JLabel("PUNTAJE: ");
        scoreTitleLabel.setFont(new Font("Verdana", Font.BOLD, 18));
        scoreTitleLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        scoreTitleLabel.setVisible(true);

        scoreLabel = new JLabel("");
        scoreLabel.setFont(new Font("Verdana", Font.BOLD, 20));
        scoreLabel.setVisible(true);
        
        hiScoreTitleLabel = new JLabel("RECORD: ");
        hiScoreTitleLabel.setFont(new Font("Verdana", Font.BOLD, 18));
        hiScoreTitleLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        hiScoreTitleLabel.setVisible(true);
        hiScoreLabel = new JLabel("");
        hiScoreLabel.setFont(new Font("Verdana", Font.BOLD, 20));
        hiScoreLabel.setVisible(true);

        scorePane = new JPanel();
        scorePane.setLayout(new GridLayout(3,2));
        scorePane.add(scoreTitleLabel);
        scorePane.add(scoreLabel);
        scorePane.add(hiScoreTitleLabel);
        scorePane.add(hiScoreLabel);

        // read hi-score from file
        hiScore = Integer.parseInt((String) gameClient.clientConfigs.get("hiscore"));
        DecimalFormat df = new DecimalFormat(SCORE_PATTERN);
        hiScoreLabel.setText(df.format(hiScore));

        buttonPane = new JPanel();
        buttonPane.add(scorePane);
        buttonPane.add(Box.createHorizontalStrut(30));
        buttonPane.add(doneButton);
        buttonPane.add(Box.createHorizontalStrut(20));
        buttonPane.add(continueButton);

        
        // ------------ TOP MESSAGE DISPLAY ------------
        topMessageDisplay = new TopMessageDisplay();
        topPane = new JPanel();
        topPane.setLayout(new BoxLayout(topPane, BoxLayout.X_AXIS));
        topPane.add(topMessageDisplay);
    }
    
    /** Button Listener. */
    private class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("done")) {
                doneButton.setEnabled(false);
                // prepare the message with the player's guess, and send it.
                Vector newPositions = new Vector();
                for (int i=0; i<numberOfImages; i++) {
                    Point p = new Point(images[i].getX(), images[i].getY());
                    newPositions.add(p);
                }
                HashMap hm = new HashMap();
                hm.put(Message.LABEL_POSITIONS, newPositions);
                gameClient.sendMessage(new Message(Message.CLIENT_POSITIONS, hm));
            }
            else if (e.getActionCommand().equals("continue")) {
                continueButton.setEnabled(false);
                topMessageDisplay.setMessage("Esperando al otro jugador...");
                sleep(100);
                gameClient.sendMessage(new Message(Message.CLIENT_ACK));
            }
        }
    }
    
    // ------------------------------------------------------------------------
    /** Main function of PhaseOne. Called from CardClient. */
    public void go() {
        Message m;
        HashMap hm;

        // - - - - - Reads the init message  - - - - - - - - - - - - - - - - -
        String prefix = GameClient.dirImages + File.separator;
        String suffix = ".gif";
        
        m = gameClient.readMessage(); gameClient.checkMessage(m, Message.SERVER_START);
        
        numberOfImages = ((Integer) m.getHashMap().get(Message.LABEL_NUMBER_OF_IMAGES)).intValue();

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

        workspace = new GameWorkspace(numberOfImages);
        JScrollPane scrollPane = new JScrollPane(workspace);
        
        mainPane = new JPanel();
        mainPane.add(topPane, BorderLayout.NORTH);
        mainPane.add(scrollPane, BorderLayout.CENTER);
        mainPane.add(buttonPane, BorderLayout.SOUTH);
        scrollPane.setPreferredSize(new Dimension(GameClient.width-50, GameClient.height-150));
        
        // - - - - - Intro screen  - - - - - - - - - - - - - - - - - - - - - -
        add(infoScreen);
        infoScreen.show(InfoScreen.INTRO_GAME);
        infoScreen.show(InfoScreen.INTRO_GAME_2);
        
        // Shows a infoscreen with the message "Waiting for the other user..."
        infoScreen.show(InfoScreen.WAITING_FOR_USER);

        gameClient.synchronize();
        
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
        removeAll(); repaint();
        add(mainPane);
        redesign(); 

        // This is a patch!
        // Without this delay, the workspace was not fully initialized before
        // the images were moved into their initial locations in the next loop,
        // and thus they were moved to the upper left corner of the screen...
        sleep(100);
        
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        
        boolean flag = true;
        while (flag) {
            m = gameClient.readMessage();

            switch (m.getMessageNumber()) {
                // -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
                
                case (Message.SERVER_END):
                    flag = false;
                    break;
                    
                // -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

                case (Message.SERVER_NEW_IMAGES):

                    // first, if there were already other images, hide them
                    if (images != null) {
                        for (int i=0; i<images.length; i++) 
                            if (images[i] != null) 
                                images[i].setVisible(false);
                    }
                    workspace.redesign();
                    
                    topMessageDisplay.setMessage("Cargando las imágenes, por favor esperá...");

// For some reason that I don't understand, this code throws a strange exception.
// The only negative effect of commenting it is that the images are never removed
// from the workspace, thus consuming memory. (agus)
//                    // now, remove them from the workspace
//                    if (images != null) {
//                        for (int i=images.length-1; i>=0; i--) {
//                            if (images[i] != null) {
//                                workspace.remove(images[i]);
//                            }
//                        }
//                    }
                        
                    // read the vector with the images, and initialize the images array
                    Vector vi = (Vector) m.getHashMap().get(Message.LABEL_IMAGES);
                    images = new GameImage[vi.size()];
                    for (int i=0; i<vi.size(); i++) {
                        images[i] = new GameImage(prefix + (String) vi.elementAt(i) + suffix);
                    }
                    
                    // move the images to their initial position
                    for (int i=0; i<numberOfImages; i++) {
                        images[i].setVisible(false);
                        workspace.addImage(images[i]);
                        Point fieldPos = workspace.getFieldPosition(i);
                        images[i].move(fieldPos.x+FIELD_OFFSET_X, fieldPos.y+FIELD_OFFSET_Y);
                        images[i].setVisible(true);
                    }

                    continueButton.setEnabled(true);
                    topMessageDisplay.setMessage("Presioná 'CONTINUAR'.");
                    
                    break;
                    
                // -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

                case (Message.SERVER_NEW_TURN):
                    gameClient.log.write(Log.ACTION_NEXT_TURN, "");

                    // get the positions for this turn
                    Vector vp = (Vector) m.getHashMap().get(Message.LABEL_POSITIONS);
                    positions = new Point[vp.size()];
                    for (int i=0; i<vp.size(); i++) {
                        Point p = (Point) vp.elementAt(i);
                        if (p.x==-1 || p.y==-1)
                            p = null;
                        positions[i] = p;
                    }
                    
                    // get the indices of the target images for this turn
                    Vector vti = (Vector) m.getHashMap().get(Message.LABEL_TARGET_IMAGES);
                    targetImages = new int[vti.size()];
                    for (int i=0; i<vti.size(); i++)
                        targetImages[i] = ((Integer) vti.elementAt(i)).intValue();

                    
                    // get the status of this player for this turn
                    if (((Boolean) m.getHashMap().get(Message.LABEL_YOU_DESCRIBE)).booleanValue())
                        playerState = PLAYER_STATE_DESCRIBING;
                    else 
                        playerState = PLAYER_STATE_PLAYING;
                    
                    
                    // slide the images into their positions for this turn
                    for (int i=0; i<numberOfImages; i++) {
                        images[i].setDraggable(false);

                        Point pos = positions[i];
                        
                        // this runnable repaints the Game after finishing the slide.
                        RunAfterSlide runnable = new RunAfterSlide(this);

                        // (AG: added july 2012)
                        // if this is a target image and this player is describing,
                        // then bring this image to the front.
                        if (playerState==PLAYER_STATE_DESCRIBING && isTargetImage(i)) {
                          workspace.moveToFront(images[i]);
                        }
                        // if the position of this image is null, or 
                        // if this is a target image and this player is playing,
                        // then move this image to its initial field.
                        if (pos==null  || (playerState==PLAYER_STATE_PLAYING && isTargetImage(i))) {
                            Point fieldPos = workspace.getFieldPosition(i);
                            images[i].slide(fieldPos.x+FIELD_OFFSET_X, fieldPos.y+FIELD_OFFSET_Y, runnable);
                        } else {
                            images[i].slide(pos.x, pos.y, runnable);
                        }
                    }
                    
                    if (playerState == PLAYER_STATE_PLAYING) {
                        topMessageDisplay.setMessage("Escuchá y mové el objeto descripto. Luego presioná 'LISTO'.");
                        
                        // enable drag&drop for the target images, so that this player can play
                        for (int i=0; i<targetImages.length; i++)
                            images[targetImages[i]].setDraggable(true);
                        
                        // enable the DONE button, so that this player can play
                        doneButton.setEnabled(true);
                    }
                    else {
                        topMessageDisplay.setMessage("Describí la ubicación del objeto que titila.");
                        
                        // calculate the blinking period, according to the speed 
                        // of the game client.  default: 100ms
                        int period = (int) Math.round((1.0 / GameClient.speed) * 100.0);
                        
                        // make the target images blink until the end of this turn,
                        // so that this player knows which are the target images
                        for (int i=0; i<targetImages.length; i++)
                            images[targetImages[i]].startBlinking(500, period, 19);
                    }
 
                    break;
                    
                // -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
                
                case (Message.SERVER_LAST_TURN_RESULTS):
                    // make the target images stop blinking, and stop being draggable
                    for (int i=0; i<targetImages.length; i++) {
                        images[targetImages[i]].stopBlinking();
                        images[targetImages[i]].setDraggable(false);
                    }
                    
                    int pnts = ((Integer) m.getHashMap().get(Message.LABEL_POINTS)).intValue();
                    score += pnts;

                    int possiblePnts = ((Integer) m.getHashMap().get(Message.LABEL_POSSIBLE_POINTS)).intValue();
                    
                    String msg = "Obtuvieron " + Integer.toString(pnts) +"/"+ Integer.toString(possiblePnts)
                                 + " puntos. Presioná 'CONTINUAR'.";
                    topMessageDisplay.setMessage(msg, TopMessageDisplay.STYLE_RIGHT);

                    gameClient.log.write(Log.ACTION_RESULTS, Integer.toString(pnts) + " points awarded.");

                    continueButton.setEnabled(true);                    
                    break;
                    
                // -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
                    
                default: 
                    gameClient.checkMessage(m, -1);
                    
            }
            
            redesign();
        }
        
        // Sends my final score to the server.
        hm = new HashMap();
        hm.put(Message.LABEL_POINTS, new Integer(score));
        gameClient.sendMessage(new Message(Message.CLIENT_MY_SCORE, hm));

        // - - - - - Final info screen  - - - - - - - - - - - - - - - - - - -
        removeAll(); repaint();
        add(infoScreen);
        String scoreStr = "El puntaje final fue: "+Integer.toString(score)+".";
        if (score>hiScore) scoreStr += "<BR>¡Lograron un nuevo record! ¡Felicitaciones!";
        infoScreen.show(InfoScreen.END_GAME, scoreStr);

        gameClient.log.write(Log.ACTION_END, "Score: " + 
            Integer.toString(score) + (score>hiScore ? " (HI)" : ""));
    }
    
    // ------------------------------------------------------------------------

    /** Redraws all the components, according to the current state. */
    public void redesign() {
        DecimalFormat df = new DecimalFormat(SCORE_PATTERN);
        scoreLabel.setText(df.format(score));
    }

    // ------------------------------------------------------------------------

    /** waits the number of milliseconds */    
    private void sleep(int millis) {
        try { Thread.currentThread().sleep(millis); } catch (InterruptedException e) {}
    }    
    
    private boolean isTargetImage(int index) {
        boolean res = false;
        for (int i=0; i<targetImages.length; i++) 
            res = res || (targetImages[i]==index);
        return res;
    }

    // ------------------------------------------------------------------------
    
}
