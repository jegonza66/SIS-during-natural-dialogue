package objectsgames;

/** <<Only for development>>
 *  This is a tool for placing the images into their initial positions on the board.
 *  Usage: drag the images into their positions and press PRINT; that will send to
 *  the standard output the locations of the objects. Press RESET to send all images
 *  into the inventory.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.io.*;
import java.util.*;
import java.net.URL;
import java.text.DecimalFormat;

public class BoardBuilder extends JPanel {
    
    // image names
//    String[] imgNames = {"belt", "horse", "lightbulb", "pineapple", "strawberry", "plane", "monkey"};
//    String[] imgNames = {"yellowlion", "ear", "mime", "nail", "bluelion", "owl", "lawnmower"};
//    String[] imgNames = {"eye", "mirror", "bluemoon", "nun", "ruler", "lemon", "yellowmoon"};
//    String[] imgNames = {"yellowmermaid", "mm", "iron", "onion", "whale", "bluemermaid", "lime"};
    
    String[] imgNames = {"loom", "yellowmoon", "worm", "bluemoon", "limo", "alien", "mirror"};
//    String[] imgNames = {"melon", "bluerhino", "menorah", "mirror", "oreo", "urn", "yellowrhino"};

    
    // components
    GameWorkspace workspace;
    JPanel mainPane, buttonPane, topPane;
    JButton printButton, resetButton;

    // variables and constants
    int numberOfImages;
    GameImage[] images;    // array with the images
    Point[] positions;     // array with the positions of the images

    int FIELD_OFFSET_X = 10;
    int FIELD_OFFSET_Y = 10;
    
    static String dir = "";
    
    /** Constructor */
    public BoardBuilder() {
        super(new BorderLayout());
        setPreferredSize(new Dimension(GameClient.width, GameClient.height));
        setOpaque(true);
        
        // - - - PRINT BUTTON - - -
        printButton = new JButton("PRINT");
        printButton.setActionCommand("print");
        printButton.addActionListener(new ButtonListener());
        printButton.setEnabled(false);
        printButton.setFont(GameClient.buttonFont);
        printButton.setBorder(GameClient.buttonBorder);
        printButton.setBackground(GameClient.buttonColor);
        printButton.setPreferredSize(new Dimension(210, 50));

        // - - - RESET BUTTON - - -
        resetButton = new JButton("RESET");
        resetButton.setActionCommand("reset");
        resetButton.addActionListener(new ButtonListener());
        resetButton.setEnabled(false);
        resetButton.setFont(GameClient.buttonFont);
        resetButton.setBorder(GameClient.buttonBorder);
        resetButton.setBackground(GameClient.buttonColor);
        resetButton.setPreferredSize(new Dimension(210, 50));

        buttonPane = new JPanel();
        buttonPane.add(printButton);
        buttonPane.add(Box.createHorizontalStrut(20));
        buttonPane.add(resetButton);
        
        // - - - Image initialization - - -
        numberOfImages = imgNames.length;
        images = new GameImage[numberOfImages];
        String prefix = BoardBuilder.dir + "images" + File.separator;
        String suffix = ".gif";
        for (int i=0; i<numberOfImages; i++)
            images[i] = new GameImage(prefix + imgNames[i] + suffix);

        // ------------ TOP MESSAGE DISPLAY ------------
        TopMessageDisplay topMessageDisplay = new TopMessageDisplay();
        topMessageDisplay.setMessage("Board Builder");
        topPane = new JPanel();
        topPane.setLayout(new BoxLayout(topPane, BoxLayout.X_AXIS));
        topPane.add(topMessageDisplay);
        
        // - - - Components - - - 
        workspace = new GameWorkspace(numberOfImages);
        JScrollPane scrollPane = new JScrollPane(workspace);
        mainPane = new JPanel();
        mainPane.add(topPane, BorderLayout.NORTH);
        mainPane.add(scrollPane, BorderLayout.CENTER);
        mainPane.add(buttonPane, BorderLayout.SOUTH);
        scrollPane.setPreferredSize(new Dimension(GameClient.width-50, GameClient.height-150));
        add(mainPane);
    }
    
    private void placeImages() {
        // move the images to their initial position
        for (int i=0; i<numberOfImages; i++) {
            images[i].setVisible(false);
            workspace.addImage(images[i]);
            Point fieldPos = workspace.getFieldPosition(i);
            images[i].move(fieldPos.x+FIELD_OFFSET_X, fieldPos.y+FIELD_OFFSET_Y);
            images[i].setVisible(true);
            images[i].setDraggable(true);
        }
        
        printButton.setEnabled(true);
        resetButton.setEnabled(true);
    }
    
    /** Button Listener. */
    private class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("print")) {
                String out = "-----------------------\n";
                
                for (int i=0; i<numberOfImages; i++) {
                    int x = images[i].getX();
                    int y = images[i].getY();
                    
                    if (images[i].getY() >= 480) {
                        x=-1; y=-1;
                    }
                    
                    out += Integer.toString(x) + " ";
                    out += Integer.toString(y) + "\n";
                }
                
                out += "-----------------------\n";

                System.out.print(out);
            }
            if (e.getActionCommand().equals("reset")) {
                for (int i=0; i<numberOfImages; i++) {
                    Point fieldPos = workspace.getFieldPosition(i);
                    images[i].move(fieldPos.x+FIELD_OFFSET_X, fieldPos.y+FIELD_OFFSET_Y);
                }
            }
        }
    }

    // ------------------------------------------------------------------------
    /** Main function. Creates an instance of GameClient. */
    public static void main(String[] args) {
       
        // read the arguments
        for (int i=0; i<args.length; i++) {
            if (args[i].startsWith("-dir=")) {
                dir = args[i].substring(5);
            }
        }
        
        if (dir.equals(""))  dir=System.getProperty("user.dir") + File.separator;
      
        //Create and set up the window.
        JFrame frame = new JFrame("Board Builder");
        frame.setUndecorated( true );
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        //Display the window and maximize it.
        frame.pack();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);

        BoardBuilder bb = new BoardBuilder();

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        
        frame.setContentPane(bb);
        frame.pack();

        bb.placeImages();
    }
    
}
