package objectsgames;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopMessageDisplay extends JEditorPane {
    public static final int STYLE_DEFAULT = 0;
    public static final int STYLE_RIGHT   = 1;
    public static final int STYLE_WRONG   = 2;
    public static final int STYLE_TIME_UP = 3;

    int width, height;
    static int RESTORE_DELAY = 2000; // in milliseconds

    String oldMessage;
    int oldStyle;

    /** Creates a new instance of TopMessageDisplay */
    public TopMessageDisplay() {
        super("text/html", "");
        width = GameClient.width;
        height = 40;
        setMessage("");
        setPreferredSize(new Dimension(width, height));
        setEditable(false);
        setBorder(new EmptyBorder(0,0,0,0));

        // If still developing, set a shorter delay.
        if (GameClient.DEVELOPING) RESTORE_DELAY = 500;
    }


    /** Changes the text in the top instructions, using the default style. */
    public void setMessage(String htmlText) {
        setMessage(htmlText, STYLE_DEFAULT);
    }

    /** Changes the text in the top instructions, using the indicated style,
     *  which can be any of the STYLE_* constants defined above. */
    public void setMessage(String htmlText, int style) {
        String html="";
        String imageFilename=null;
        String bgColor;
        String fontColor;

        switch (style) {
            case STYLE_RIGHT:
                bgColor   = "#AAFFAA";
                fontColor = "#000000";
//DEL                fontColor = "#808000";  // olive green
                break;
//            case STYLE_WRONG:
//                bgColor   = "#FFAAAA";
//                fontColor = "#000000";
//                imageFilename = "file:///"+GameClient.dirImages+"tongue.gif";
//                break;
//            case STYLE_TIME_UP:
//                bgColor   = "#FFAAAA";
//                fontColor = "#000000";
//                imageFilename = "file:///"+GameClient.dirImages+"clock.gif";
//                break;
            default:
                bgColor   = "#CCCCFF";
                fontColor = "#000000";
                break;
        }

        html += "<body bgcolor='"+bgColor+"'>";
//DEL        html += "<body>";
        html += "<table width='"+ width +"' height='40' cellpadding='0' cellspacing='0'><tr>";
        if (imageFilename!=null) {
            html += "<td align='right' valign='bottom'><img src='"+imageFilename+"'></td>";
            html += "<td align='left' valign='top'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        }
        else {
            html += "<td align='center' valign='middle'>";
        }
        html += "<font style='font-family: arial; font-size:24px; font-weight:bold; color:"+fontColor+"'>";
//DEL        html += "<font face=verdana size=\"26px\" color=\""+fontColor+"\"><b>";
        html += htmlText;
//DEL        html += "</b></font>";
        html += "</font>";
        html += "</td>";
        html += "</tr></table>";
        html += "</body>";

        setText(html);
    }

    /** Shows newHtmlText for some time, and then go back to currentHtmlText.
     *  using the indicated styles, which can be any of the STYLE_* constants. */
    public void temporaryMessage(String newHtmlText, int newStyle, String currentHtmlText, int currentStyle) {
        setMessage(newHtmlText, newStyle);
        oldMessage = currentHtmlText;
        oldStyle = currentStyle;

        // sleep for some time, while showing the message to the user.
        try { Thread.currentThread().sleep(RESTORE_DELAY); }
	catch (InterruptedException e) {}

        setMessage(oldMessage, oldStyle);
    }
}
