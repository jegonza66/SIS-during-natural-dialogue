package objectsgames;

public class Main {

  public static void main(String[] args) {
    String dir = "";
    String iniFilename = "";
    String which = ""; // client or server

    // read the arguments
    for (int i=0; i<args.length; i++) {
      if (args[i].startsWith("-dir=")) {
        dir = args[i].substring(5);
      }
      else if (args[i].startsWith("-ini=")) {
        iniFilename = args[i].substring(5);
      }
      else if (args[i].startsWith("-client")) {
        which = "client";
      }
      else if (args[i].startsWith("-server")) {
        which = "server";
      }
    }

//    System.out.println(dir);

    if (dir.isEmpty() || iniFilename.isEmpty() || which.isEmpty()) {
      System.err.println("Usage: java -jar UBAObjects.jar (-server|-client) -dir=PATH -ini=INIFILE");
    }
    else {
      if (which.equals("client")) {
        GameClient.start(dir, iniFilename);
      }
      else if (which.equals("server")) {
        GameServer.start(dir, iniFilename);
      }
    }
  }
}
