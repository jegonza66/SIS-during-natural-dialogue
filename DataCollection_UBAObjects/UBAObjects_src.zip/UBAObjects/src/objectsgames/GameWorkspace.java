package objectsgames;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.text.DecimalFormat;
public class GameWorkspace extends JLayeredPane implements MouseListener {

    public Vector images;
    
    int numberOfFields;
    int fieldHeight = 120;
    
    // ----------------------------------------------------------------------
    public GameWorkspace(int numberOfFields) {
        this.numberOfFields = numberOfFields;
        
        images = new Vector();
        addMouseListener(this);
        
        setBackground(new Color(245, 245, 245));
        setOpaque(true);
    }
    
//    public Game game() {
//        return (Game)getParent().getParent().getParent();
//    }
//
    
    /** This function receives an GameImage and adds it to the workspace. */
    public void addImage(GameImage obj) {
        images.add(obj);
        add(obj);
        redesign();
    }
    
    public void removeImage(GameImage obj) {
        images.remove(obj);
        remove(obj);
        redesign();
    }
    public void removeAllImages() {
        images.removeAllElements();
        removeAll();
        redesign();
    }

    // ----------------------------------------------------------------------

    /** Important! Overrides the paintComponent() method of JComponent. */
    public void paintComponent(Graphics g) {
        int h = getHeight();
        int w = getWidth();

        // paint the inventory's background
        g.setColor(new Color(180, 237, 180));
        g.fillRect(0, h-fieldHeight, w, fieldHeight);
        
        // draw the inventory's lines
        g.setColor(Color.BLACK);
        int lineThickness = 3;
        
        // draw the top and bottom lines of the fields
        for (int i=0; i<lineThickness; i++) {
            g.drawLine(0, h-fieldHeight+i, w, h-fieldHeight+i);
            g.drawLine(0, h-i, w, h-i);
        }
        
        // draw the vertical lines for the fields, except for the rightmost one
        int fieldWidth = w / numberOfFields;
        for (int j=0; j<numberOfFields; j++) {
            for (int i=0; i<lineThickness; i++) 
                g.drawLine(j*fieldWidth+i, h-fieldHeight, j*fieldWidth+i, h);
        }
        // draw the rightmost line
        for (int i=0; i<lineThickness; i++) 
            g.drawLine(w-i, h-fieldHeight, w-i, h);
        
    }
    
    public void redesign() {
        revalidate();
        repaint();
    }
    
    // ----------------------------------------------------------------------
    
    public Point getFieldPosition(int fieldNumber) {
        int x = fieldNumber * (getWidth() / numberOfFields);
        int y = getHeight() - fieldHeight;
        Point d = new Point(x, y);
        return d;
    }
    
    // ----------------------------------------------------------------------
    
    public void mouseClicked(MouseEvent e) { }
    public void mouseEntered(MouseEvent e) { }
    public void mouseExited(MouseEvent e) { }
    public void mousePressed(MouseEvent e) { }
    public void mouseReleased(MouseEvent e) { }
    
    // ----------------------------------------------------------------------
}
