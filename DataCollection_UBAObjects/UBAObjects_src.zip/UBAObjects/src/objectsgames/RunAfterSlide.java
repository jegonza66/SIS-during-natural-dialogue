package objectsgames;

public class RunAfterSlide implements Runnable {
    Game game;
    
    public RunAfterSlide(Game game) {
        this.game = game;
    }

    public void run() {
        if (game != null) game.repaint();
    }
}
