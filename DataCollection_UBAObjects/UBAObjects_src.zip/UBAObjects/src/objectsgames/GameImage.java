package objectsgames;

import java.awt.*;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.awt.image.ImageObserver;
import java.net.URL;
import java.io.*;
public class GameImage extends JPanel implements MouseMotionListener, MouseListener
{
    public int width, height;

    boolean draggable = false;  // Says if this image can be dragged over.
    boolean draggedOver;        // Says if this image is being dragged over.
    DragSource dragSource;
    DropTarget dropTarget;

    int dragStartX, dragStartY;
    String filename;
    Image img;
    
    public static final Color colorSelected = Color.BLUE;
    public static final Color colorObject   = Color.RED;

    // Timer to make the image blink
    java.util.Timer blinkTimer;    
    
    // Variables/constants for the sliding effect.
    javax.swing.Timer slideTimer;
    int slideX, slideY;                 // current position of the sliding card
    int slideToX, slideToY;             // final position of the sliding card
    double slideDeltaX, slideDeltaY;    // increment of each step
    int slideDelay;

    // code to run after the slide
    RunAfterSlide slideRunnable;
    
    final int slideNumSteps=10, slideThreshold=10; // constants
    
    /** Constructor */
    public GameImage(String filename) {
        addMouseMotionListener(this);
        addMouseListener(this);
        setFocusable(true);
        setOpaque(false);
        this.filename = filename;
        img = getToolkit().getImage(this.filename);
        while ((width  = img.getWidth(this))  == -1) {}
        while ((height = img.getHeight(this)) == -1) {}
        width=105; height=105;
        setBounds(0, 0, width, height);
        
        // slideDelay determines the speed of the sliding effect,
        // and depends on the speed of the game client.
        slideDelay = (int) Math.round((1.0 / GameClient.speed) * 10.0);
        
        slideTimer = new javax.swing.Timer(slideDelay, new SlideActionListener());
//        blinkTimer = new java.util.Timer();
    }

    /** Important! Overrides the paintComponent() method of JComponent. */
    public void paintComponent(Graphics g) {
        g.drawImage(img, 0, 0, width, height, this);
        g.dispose();
    }

    /** Sets the draggable property. */
    public void setDraggable(boolean b) {
        if (b) workspace().moveToFront(this);
        draggable = b;
    }
    
    /** Sets the draggedOver property. */
    public void setDraggedOver(boolean b) {
        draggedOver = b;
        repaint();
    }
    
    /** Returns the GameWorkspace in which this GameImage is. */
    public GameWorkspace workspace() {
        return (GameWorkspace)getParent();
    }

    // ----------------------------------------------------------------------

    public void mouseDragged(MouseEvent e) {
        if (draggable) {
            int dragCurrentX = e.getX();
            int dragCurrentY = e.getY();
            int x = e.getComponent().getX() + dragCurrentX - dragStartX;
            int y = e.getComponent().getY() + dragCurrentY - dragStartY;
            
            // check: don't go beyond the workspace boundaries 
            if (x<0) x=0;
            if (y<0) y=0;
            int ww = workspace().getSize().width  - getSize().width;
            int wh = workspace().getSize().height - getSize().height;
            if (x>ww) x=ww;
            if (y>wh) y=wh;
            
            e.getComponent().setLocation(x,y);
        }
    }
    public void mouseMoved(MouseEvent e)   { }
    public void mouseClicked(MouseEvent e) { }
    public void mouseEntered(MouseEvent e) { }
    public void mouseExited(MouseEvent e)  { }
    public void mousePressed(MouseEvent e) {
        if (draggable) {
            dragStartX = e.getX();
            dragStartY = e.getY();
        }
    }
    public void mouseReleased(MouseEvent e) { }

   // ----------------------------------------------------------------------
    
    /** Move the card to (x,y). */
    public void move(int x, int y) {
        setBounds(x, y, width, height);
    }
    
    /** Runs runnable after the slide effect. */
    public void slide(int toX, int toY, RunAfterSlide runnable) {
        // initialize the parameters of how the card will slide
        slideX = getX();
        slideY = getY();
        slideToX = toX;
        slideToY = toY;
        
        slideDeltaX = ((double)(slideToX - slideX)) / ((double)slideNumSteps);
        slideDeltaY = ((double)(slideToY - slideY)) / ((double)slideNumSteps);
        
        slideRunnable = runnable;
        
        // start the sliding effect......
        slideTimer.start();
    }
    
    //this ActionListener is instantiated in the declaration of the Timer
    private class SlideActionListener implements ActionListener {            
        public void actionPerformed (ActionEvent event) {
            // run the first runnable if needed.
            if (slideRunnable != null) {
                slideRunnable.run();
                slideRunnable = null;
            }                    
            slideX += (int)slideDeltaX;
            slideY += (int)slideDeltaY;
            
            if ((Math.abs(slideX-slideToX) <= slideThreshold) &&
                (Math.abs(slideY-slideToY) <= slideThreshold)) {
                slideX = slideToX;
                slideY = slideToY;
                slideTimer.stop();
            }

            setBounds(slideX, slideY, width, height);
            repaint();
        }                
    }

   // ----------------------------------------------------------------------
    
    /** Makes the image blink.
     * delay:  time to wait before starting (in milliseconds) 
     * period: blinking period (in milliseconds) 
     * iter:   number of blinks
     * proportionOnOff: number of times that the image is ON for each time it's OFF. 
     */
    public void blink(int delay, int period, int proportionOnOff, int iter) {
        blinkTimer = new java.util.Timer();
        blinkTimer.schedule(new ToggleVisible(this, proportionOnOff, iter), delay, period);
    }

    public void startBlinking(int delay, int period, int proportionOnOff) {
        blinkTimer = new java.util.Timer();
        blinkTimer.schedule(new ToggleVisible(this, proportionOnOff), delay, period);
    }
    
    public void stopBlinking() {
        if (blinkTimer != null) blinkTimer.cancel();
        setVisible(true);
    }
    
   // ----------------------------------------------------------------------
    
}
